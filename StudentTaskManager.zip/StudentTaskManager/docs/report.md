# VITyarthi Report Content — Student Task Manager

## 1. Cover Page
**Project:** Student Task Manager  
**Technology:** Java  
**Application Type:** Console-based  
**Purpose:** Academic task and deadline management

## 2. Introduction
Student Task Manager is a lightweight Java application that helps students organize academic tasks, priorities, deadlines and completion status.

## 3. Problem Statement
Students may forget assignments and deadlines when tasks are tracked manually. A simple local task manager can make academic work easier to organize.

## 4. Functional Requirements
- Add, view, update and delete tasks
- Search by title or subject
- Filter by priority or status
- Display overdue tasks
- Mark tasks completed/pending
- Generate task statistics
- Save/load tasks from a text file

## 5. Non-Functional Requirements
- **Usability:** Simple numbered console menu.
- **Performance:** ArrayList provides fast access for a small task set.
- **Reliability:** Input validation and exception handling prevent normal input errors from stopping the program.
- **Maintainability:** Separate classes for data, management, validation, storage and reporting.
- **Security:** Local-only application with no network/API dependency.
- **Resource Efficiency:** Small text file and lightweight Java objects.

## 6. System Architecture
Layered simple architecture:
**Main → TaskManager → FileStorage**, with **TaskValidator** for validation and **ReportGenerator** for statistics.

## 7. Design Diagrams
Architecture, workflow, use case, class, sequence and storage diagrams are provided in `docs/diagrams.md`.

## 8. Design Decisions & Rationale
- Console UI keeps the project small and easy to demonstrate.
- ArrayList is sufficient for a small academic task list.
- Enums avoid invalid priority/status values.
- Text-file storage avoids database complexity.
- Separate classes improve maintainability.

## 9. Implementation Details
`Task` stores task information. `TaskManager` performs operations. `TaskValidator` validates input. `FileStorage` provides persistence. `ReportGenerator` calculates simple statistics. `Main` handles the menu.

## 10. Screenshots / Results
Take screenshots during demonstration of:
1. Main menu
2. Add task
3. View tasks
4. Search/filter
5. Mark complete
6. Task report
7. Test output

## 11. Testing Approach
`TaskManagerTest` checks add, update, search, filter, completion, deletion, duplicate ID validation and file persistence.

## 12. Challenges Faced
- Handling invalid console input
- Validating dates
- Keeping file records consistent
- Maintaining a simple modular structure

## 13. Learnings & Key Takeaways
- Practical Java OOP
- Collections
- Enums
- File I/O
- Exception handling
- Modular project design
- Basic testing

## 14. Future Enhancements
Sorting, reminders, export, optional GUI and optional authentication can be added later.

## 15. References
- Java SE documentation
- VITyarthi Build Your Own Project guidelines
