# Student Task Manager — Design Diagrams

## 1. System Architecture
```mermaid
flowchart TD
    U[Student] --> M[Main Console Menu]
    M --> TM[TaskManager]
    TM --> V[TaskValidator]
    TM --> FS[FileStorage]
    TM --> R[ReportGenerator]
    FS --> D[(data/tasks.txt)]
```

## 2. User Workflow
```mermaid
flowchart TD
    A[Start] --> B[Load tasks from file]
    B --> C[Show menu]
    C --> D{Choose option}
    D -->|Add/Update/Delete| E[Validate input]
    E --> F[Change task list]
    F --> G[Save file]
    D -->|Search/Filter| H[Display results]
    D -->|Complete/Pending| I[Change status]
    I --> G
    D -->|Report| J[Show statistics]
    D -->|Exit| K[End]
    G --> C
    H --> C
    J --> C
```

## 3. Use Case Diagram
```mermaid
flowchart LR
    S((Student))
    A[Add Task]
    B[View Tasks]
    C[Update Task]
    D[Delete Task]
    E[Search/Filter]
    F[Change Status]
    G[View Report]

    S --> A
    S --> B
    S --> C
    S --> D
    S --> E
    S --> F
    S --> G
```

## 4. Class Diagram
```mermaid
classDiagram
    class Task {
        -int id
        -String title
        -String subject
        -Priority priority
        -String dueDate
        -Status status
        +toFileString()
        +fromFileString()
    }

    class TaskManager {
        -List~Task~ tasks
        +addTask()
        +updateTask()
        +deleteTask()
        +searchByTitle()
        +searchBySubject()
        +filterByPriority()
        +filterByStatus()
        +overdueTasks()
        +setStatus()
    }

    class TaskValidator {
        +validateText()
        +validateId()
        +validateDate()
        +validatePriority()
        +validateStatus()
    }

    class FileStorage {
        +load()
        +save()
    }

    class ReportGenerator {
        +printReport()
    }

    class Priority {
        <<enumeration>>
        LOW
        MEDIUM
        HIGH
    }

    class Status {
        <<enumeration>>
        PENDING
        COMPLETED
    }

    TaskManager --> Task
    TaskManager --> FileStorage
    TaskManager --> TaskValidator
    Task --> Priority
    Task --> Status
    ReportGenerator --> Task
```

## 5. Sequence Diagram
```mermaid
sequenceDiagram
    actor Student
    participant Main
    participant TaskManager
    participant Validator
    participant File as FileStorage

    Student->>Main: Select Add Task
    Main->>Validator: Validate input
    Validator-->>Main: Valid
    Main->>TaskManager: addTask(task)
    TaskManager->>File: save(tasks)
    File-->>TaskManager: Saved
    TaskManager-->>Main: Success
    Main-->>Student: Display message
```

## 6. Data/Storage Design
```mermaid
erDiagram
    TASK {
        int id
        string title
        string subject
        string priority
        string dueDate
        string status
    }
```

File record:
```text
ID|TITLE|SUBJECT|PRIORITY|DUE_DATE|STATUS
```
