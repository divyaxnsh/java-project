# Student Task Manager — Project Statement

## 1. Problem Statement
Students often manage assignments and academic deadlines manually, making it easy to miss important work. The Student Task Manager provides a simple console application for organizing academic tasks.

## 2. Scope
The project covers task creation, viewing, updating, deletion, searching, filtering, status management, reporting, and file-based persistence.

## 3. Target Users
College students who need a lightweight academic task tracker.

## 4. High-Level Features
- Add, view, update and delete tasks
- Search by title or subject
- Filter by priority or status
- Display overdue tasks
- Mark tasks completed/pending
- Generate a simple task report
- Save and load tasks using a text file
