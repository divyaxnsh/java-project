import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class TaskManagerTest {
    public static void main(String[] args) throws Exception {
        Path temp = Files.createTempFile("student_tasks_test", ".txt");
        FileStorage storage = new FileStorage(temp.toString());
        TaskManager manager = new TaskManager(storage);

        Task task = new Task(1, "DBMS Assignment", "DBMS",
                Priority.HIGH, "10-09-2026", Status.PENDING);

        manager.addTask(task);
        check(manager.getAllTasks().size() == 1, "Add task");

        manager.updateTask(1, "Updated Assignment", "DBMS",
                Priority.MEDIUM, "12-09-2026");
        check(manager.findById(1).getTitle().equals("Updated Assignment"), "Update task");

        check(manager.searchByTitle("updated").size() == 1, "Search task");
        check(manager.filterByPriority(Priority.MEDIUM).size() == 1, "Filter task");

        manager.setStatus(1, Status.COMPLETED);
        check(manager.findById(1).getStatus() == Status.COMPLETED, "Complete task");

        check(manager.deleteTask(1), "Delete task");

        manager.addTask(task);
        TaskManager loaded = new TaskManager(storage);
        check(loaded.getAllTasks().size() == 1, "File storage");

        try {
            loaded.addTask(task);
            throw new RuntimeException("Validation failed: duplicate ID accepted");
        } catch (IllegalArgumentException expected) {
            System.out.println("PASS: Duplicate ID validation");
        }

        Files.deleteIfExists(temp);
        System.out.println("All tests passed.");
    }

    private static void check(boolean condition, String name) {
        if (!condition) throw new RuntimeException("FAIL: " + name);
        System.out.println("PASS: " + name);
    }
}
