# Student Task Manager

## Overview
Student Task Manager is a small Java console application for managing assignments, academic tasks and deadlines.

## Problem Statement
Students can miss academic deadlines when tasks are tracked manually. This application keeps tasks in one simple place.

## Objectives
- Manage academic tasks
- Track deadlines and priorities
- Search and filter tasks
- Track completion status
- Store tasks permanently using a text file

## Features
1. Add Task
2. View All Tasks
3. Update Task
4. Delete Task
5. Search by title/subject
6. Filter by priority/status
7. Display overdue tasks
8. Mark complete/pending
9. Task report
10. File persistence

## Functional Modules
- Task Management
- Task Search & Filter
- Task Status
- Simple Report

## Technologies
- Java
- OOP
- Collections Framework
- Java File I/O
- Console input

## OOP Concepts
- Encapsulation through private fields and getters/setters
- Classes and objects
- Constructors
- Methods
- Enums
- Exception handling
- Collections

## Project Structure
```text
StudentTaskManager/
├── src/
│   ├── Main.java
│   ├── Task.java
│   ├── TaskManager.java
│   ├── TaskValidator.java
│   ├── FileStorage.java
│   ├── ReportGenerator.java
│   ├── Priority.java
│   └── Status.java
├── data/
│   └── tasks.txt
├── test/
│   └── TaskManagerTest.java
├── docs/
│   └── diagrams.md
├── README.md
└── statement.md
```

## Requirements
- JDK 17 or later recommended
- Command Prompt, PowerShell, VS Code, IntelliJ IDEA or Eclipse

## Installation
Open a terminal in the project folder.

## Compile
Windows PowerShell / Command Prompt:
```text
javac -d out src/*.java test/TaskManagerTest.java
```

If your shell does not expand `*.java`, compile all files individually or use:
```text
javac -d out src\*.java test\TaskManagerTest.java
```

## Run
```text
java -cp out Main
```

## Test
```text
java -cp out TaskManagerTest
```

Expected final line:
```text
All tests passed.
```

## Data Format
`data/tasks.txt` uses:
```text
ID|TITLE|SUBJECT|PRIORITY|DUE_DATE|STATUS
```
Example:
```text
101|Complete DBMS Assignment|DBMS|HIGH|10-09-2026|PENDING
```

The application creates the data directory/file if needed. Tasks are loaded at startup and saved after add/update/delete/status changes.

## Sample Menu
```text
================================
       STUDENT TASK MANAGER
================================
1. Add Task
2. View All Tasks
3. Update Task
4. Delete Task
5. Search Task
6. Filter Tasks
7. Mark Task Complete
8. Mark Task Pending
9. Task Report
10. Exit
Enter choice:
```

## Non-Functional Requirements
### Usability
Clear numbered menu and simple messages make the application easy to operate.

### Performance
Uses an in-memory `ArrayList`, suitable for a small student task list.

### Reliability
Invalid normal input is handled with validation and exceptions instead of crashing the menu.

### Maintainability
Separate classes divide task data, business logic, validation, storage and reporting.

### Security
The application has no network service or external API and stores only the entered task information locally.

### Resource Efficiency
It uses a small text file and simple Java collections, with no database server.

## Testing Approach
The included `TaskManagerTest.java` checks:
- Adding
- Updating
- Searching
- Filtering
- Completing
- Deleting
- Duplicate ID validation
- File save/load

## Future Enhancements
- Sort tasks by deadline
- Desktop GUI
- Optional login
- Export reports
- Reminder notifications

## Design Artifacts
See `docs/diagrams.md` for the architecture, workflow, use case, class, sequence and storage diagrams.

## Viva Summary
This project demonstrates Java OOP, collections, enums, validation, exception handling, file I/O and modular design without a database or external framework.
