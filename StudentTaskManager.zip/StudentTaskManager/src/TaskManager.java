import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {
    private final List<Task> tasks;
    private final FileStorage storage;
    private static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("dd-MM-uuuu");

    public TaskManager(FileStorage storage) {
        this.storage = storage;
        this.tasks = storage.load();
    }

    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks);
    }

    public void addTask(Task task) {
        if (findById(task.getId()) != null)
            throw new IllegalArgumentException("Duplicate task ID.");
        tasks.add(task);
        storage.save(tasks);
    }

    public boolean updateTask(int id, String title, String subject,
                              Priority priority, String dueDate) {
        Task task = findById(id);
        if (task == null) return false;
        task.setTitle(title);
        task.setSubject(subject);
        task.setPriority(priority);
        task.setDueDate(dueDate);
        storage.save(tasks);
        return true;
    }

    public boolean deleteTask(int id) {
        Task task = findById(id);
        if (task == null) return false;
        tasks.remove(task);
        storage.save(tasks);
        return true;
    }

    public boolean setStatus(int id, Status status) {
        Task task = findById(id);
        if (task == null) return false;
        task.setStatus(status);
        storage.save(tasks);
        return true;
    }

    public Task findById(int id) {
        for (Task task : tasks)
            if (task.getId() == id) return task;
        return null;
    }

    public List<Task> searchByTitle(String text) {
        List<Task> result = new ArrayList<>();
        for (Task task : tasks)
            if (task.getTitle().toLowerCase().contains(text.toLowerCase()))
                result.add(task);
        return result;
    }

    public List<Task> searchBySubject(String text) {
        List<Task> result = new ArrayList<>();
        for (Task task : tasks)
            if (task.getSubject().toLowerCase().contains(text.toLowerCase()))
                result.add(task);
        return result;
    }

    public List<Task> filterByPriority(Priority priority) {
        List<Task> result = new ArrayList<>();
        for (Task task : tasks)
            if (task.getPriority() == priority) result.add(task);
        return result;
    }

    public List<Task> filterByStatus(Status status) {
        List<Task> result = new ArrayList<>();
        for (Task task : tasks)
            if (task.getStatus() == status) result.add(task);
        return result;
    }

    public List<Task> overdueTasks() {
        List<Task> result = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (Task task : tasks) {
            LocalDate due = LocalDate.parse(task.getDueDate(), FORMAT);
            if (due.isBefore(today) && task.getStatus() == Status.PENDING)
                result.add(task);
        }
        return result;
    }
}
