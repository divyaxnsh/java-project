import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

public class TaskValidator {
    private static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("dd-MM-uuuu")
                    .withResolverStyle(ResolverStyle.STRICT);

    public static void validateText(String value, String field) {
        if (value == null || value.trim().isEmpty())
            throw new IllegalArgumentException(field + " cannot be empty.");
        if (value.contains("|"))
            throw new IllegalArgumentException(field + " cannot contain '|'.");
    }

    public static void validateId(int id) {
        if (id <= 0) throw new IllegalArgumentException("Task ID must be positive.");
    }

    public static void validateDate(String date) {
        try {
            LocalDate.parse(date, FORMAT);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Date must be valid and use dd-MM-yyyy.");
        }
    }

    public static void validatePriority(String value) {
        try {
            Priority.valueOf(value.toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("Priority must be LOW, MEDIUM or HIGH.");
        }
    }

    public static void validateStatus(String value) {
        try {
            Status.valueOf(value.toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("Status must be PENDING or COMPLETED.");
        }
    }
}
