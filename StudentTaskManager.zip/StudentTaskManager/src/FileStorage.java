import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileStorage {
    private final File file;

    public FileStorage(String path) {
        file = new File(path);
    }

    public List<Task> load() {
        List<Task> tasks = new ArrayList<>();
        if (!file.exists()) return tasks;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    try {
                        tasks.add(Task.fromFileString(line));
                    } catch (Exception e) {
                        System.out.println("Skipped invalid data record.");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Could not load tasks: " + e.getMessage());
        }
        return tasks;
    }

    public void save(List<Task> tasks) {
        File parent = file.getParentFile();
        if (parent != null) parent.mkdirs();

        try (PrintWriter out = new PrintWriter(new FileWriter(file))) {
            for (Task task : tasks) out.println(task.toFileString());
        } catch (IOException e) {
            System.out.println("Could not save tasks: " + e.getMessage());
        }
    }
}
