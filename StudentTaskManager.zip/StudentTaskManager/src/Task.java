public class Task {
    private int id;
    private String title;
    private String subject;
    private Priority priority;
    private String dueDate;
    private Status status;

    public Task(int id, String title, String subject, Priority priority,
                String dueDate, Status status) {
        this.id = id;
        this.title = title;
        this.subject = subject;
        this.priority = priority;
        this.dueDate = dueDate;
        this.status = status;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getSubject() { return subject; }
    public Priority getPriority() { return priority; }
    public String getDueDate() { return dueDate; }
    public Status getStatus() { return status; }

    public void setTitle(String title) { this.title = title; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public void setDueDate(String dueDate) { this.dueDate = dueDate; }
    public void setStatus(Status status) { this.status = status; }

    public String toFileString() {
        return id + "|" + title + "|" + subject + "|" + priority + "|" + dueDate + "|" + status;
    }

    public static Task fromFileString(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length != 6) throw new IllegalArgumentException("Invalid task record");
        return new Task(Integer.parseInt(p[0]), p[1], p[2],
                Priority.valueOf(p[3]), p[4], Status.valueOf(p[5]));
    }

    @Override
    public String toString() {
        return String.format("%-5d %-28s %-15s %-8s %-12s %-10s",
                id, title, subject, priority, dueDate, status);
    }
}
