import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final TaskManager manager =
            new TaskManager(new FileStorage("data/tasks.txt"));

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {
                    case 1 -> addTask();
                    case 2 -> printTasks(manager.getAllTasks());
                    case 3 -> updateTask();
                    case 4 -> deleteTask();
                    case 5 -> searchTask();
                    case 6 -> filterTasks();
                    case 7 -> changeStatus(Status.COMPLETED);
                    case 8 -> changeStatus(Status.PENDING);
                    case 9 -> ReportGenerator.printReport(
                            manager.getAllTasks(), manager.overdueTasks());
                    case 10 -> {
                        System.out.println("Thank you. Goodbye!");
                        return;
                    }
                    default -> System.out.println("Invalid choice. Enter 1-10.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }

    private static void showMenu() {
        System.out.println("\n================================");
        System.out.println("       STUDENT TASK MANAGER");
        System.out.println("================================");
        System.out.println("1. Add Task");
        System.out.println("2. View All Tasks");
        System.out.println("3. Update Task");
        System.out.println("4. Delete Task");
        System.out.println("5. Search Task");
        System.out.println("6. Filter Tasks");
        System.out.println("7. Mark Task Complete");
        System.out.println("8. Mark Task Pending");
        System.out.println("9. Task Report");
        System.out.println("10. Exit");
    }

    private static void addTask() {
        int id = readInt("Task ID: ");
        String title = readText("Title: ");
        String subject = readText("Subject: ");
        Priority priority = readPriority();
        String date = readDate();

        TaskValidator.validateId(id);
        Task task = new Task(id, title, subject, priority, date, Status.PENDING);
        manager.addTask(task);
        System.out.println("Task added successfully.");
    }

    private static void updateTask() {
        int id = readInt("Task ID to update: ");
        if (manager.findById(id) == null) {
            System.out.println("Task not found.");
            return;
        }

        String title = readText("New title: ");
        String subject = readText("New subject: ");
        Priority priority = readPriority();
        String date = readDate();

        if (manager.updateTask(id, title, subject, priority, date))
            System.out.println("Task updated successfully.");
    }

    private static void deleteTask() {
        int id = readInt("Task ID to delete: ");
        System.out.println(manager.deleteTask(id)
                ? "Task deleted successfully." : "Task not found.");
    }

    private static void searchTask() {
        System.out.println("1. Search by title");
        System.out.println("2. Search by subject");
        int choice = readInt("Choice: ");
        String text = readText("Search text: ");

        if (choice == 1) printTasks(manager.searchByTitle(text));
        else if (choice == 2) printTasks(manager.searchBySubject(text));
        else System.out.println("Invalid search choice.");
    }

    private static void filterTasks() {
        System.out.println("1. Priority");
        System.out.println("2. Status");
        System.out.println("3. Overdue");
        int choice = readInt("Choice: ");

        if (choice == 1) printTasks(manager.filterByPriority(readPriority()));
        else if (choice == 2) printTasks(manager.filterByStatus(readStatus()));
        else if (choice == 3) printTasks(manager.overdueTasks());
        else System.out.println("Invalid filter choice.");
    }

    private static void changeStatus(Status status) {
        int id = readInt("Task ID: ");
        System.out.println(manager.setStatus(id, status)
                ? "Task status updated." : "Task not found.");
    }

    private static Priority readPriority() {
        while (true) {
            try {
                String value = readText("Priority (LOW/MEDIUM/HIGH): ");
                TaskValidator.validatePriority(value);
                return Priority.valueOf(value.toUpperCase());
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static Status readStatus() {
        while (true) {
            try {
                String value = readText("Status (PENDING/COMPLETED): ");
                TaskValidator.validateStatus(value);
                return Status.valueOf(value.toUpperCase());
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static String readDate() {
        while (true) {
            try {
                String date = readText("Due date (dd-MM-yyyy): ");
                TaskValidator.validateDate(date);
                return date;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static String readText(String message) {
        while (true) {
            System.out.print(message);
            String value = sc.nextLine().trim();
            try {
                TaskValidator.validateText(value, message.replace(":", ""));
                return value;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: Enter a valid number.");
            }
        }
    }

    private static void printTasks(List<Task> tasks) {
        if (tasks.isEmpty()) {
            System.out.println("No tasks found.");
            return;
        }

        System.out.println("\nID    TITLE                        SUBJECT         PRIORITY DUE DATE     STATUS");
        System.out.println("--------------------------------------------------------------------------------");
        for (Task task : tasks) System.out.println(task);
    }
}
