import java.util.List;

public class ReportGenerator {
    public static void printReport(List<Task> tasks, List<Task> overdue) {
        int completed = 0, high = 0;

        for (Task task : tasks) {
            if (task.getStatus() == Status.COMPLETED) completed++;
            if (task.getPriority() == Priority.HIGH) high++;
        }

        System.out.println("\n========== TASK REPORT ==========");
        System.out.println("Total Tasks      : " + tasks.size());
        System.out.println("Completed Tasks  : " + completed);
        System.out.println("Pending Tasks    : " + (tasks.size() - completed));
        System.out.println("High-Priority    : " + high);
        System.out.println("Overdue Tasks    : " + overdue.size());
        System.out.println("=================================");
    }
}
